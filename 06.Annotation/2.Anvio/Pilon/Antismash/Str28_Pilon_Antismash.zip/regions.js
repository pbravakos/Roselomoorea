var recordData = [
    {
        "length": 925944,
        "seq_id": "c00001_Scaffol..",
        "regions": []
    },
    {
        "length": 58801,
        "seq_id": "c00002_Scaffol..",
        "regions": []
    },
    {
        "length": 63143,
        "seq_id": "c00003_Scaffol..",
        "regions": []
    },
    {
        "length": 80756,
        "seq_id": "c00004_Scaffol..",
        "regions": []
    },
    {
        "length": 28649,
        "seq_id": "c00005_Scaffol..",
        "regions": []
    },
    {
        "length": 290599,
        "seq_id": "c00006_Scaffol..",
        "regions": []
    },
    {
        "length": 12264,
        "seq_id": "c00007_Scaffol..",
        "regions": []
    },
    {
        "length": 76351,
        "seq_id": "c00008_Scaffol..",
        "regions": []
    },
    {
        "length": 1091034,
        "seq_id": "c00009_Scaffol..",
        "regions": []
    },
    {
        "length": 1395003,
        "seq_id": "c00010_Scaffol..",
        "regions": []
    },
    {
        "length": 1243648,
        "seq_id": "c00011_Scaffol..",
        "regions": []
    }
];
var all_regions = {
    "order": []
};
var details_data = {
    "nrpspks": {},
    "pfam": {}
};
var resultsData = {};
